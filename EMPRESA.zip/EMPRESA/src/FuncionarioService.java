import java.util.ArrayList;
import java.util.List;

public class FuncionarioService {
    private FuncionarioRepository repository = new FuncionarioRepository();
    private FuncionarioMapper mapper = new FuncionarioMapper();

    public void cadastrar(FuncionarioDTO dto) {
        Funcionario entidade = mapper.paraEntidade(dto);
        repository.salvar(entidade);
    }

    public List<FuncionarioDTO> listar() {
        List<FuncionarioDTO> dtos = new ArrayList<>();
        for (Funcionario f : repository.buscarTodos()) {
            dtos.add(mapper.paraDTO(f));
        }
        return dtos;
    }
}