import java.util.List;

public class FuncionarioController {
    private FuncionarioService service = new FuncionarioService();

    public void adicionar(Long id, String nome, String cargo, Double salario) {
        FuncionarioDTO novo = new FuncionarioDTO(id, nome, cargo, salario);
        service.cadastrar(novo);
        System.out.println("Funcionario cadastrado com sucesso!");
    }

    public void exibirTodos() {
        List<FuncionarioDTO> lista = service.listar();
        if (lista.isEmpty()) {
            System.out.println("Nenhum funcionario encontrado.");
        } else {
            for (FuncionarioDTO dto : lista) {
                System.out.println(dto);
            }
        }
    }
}