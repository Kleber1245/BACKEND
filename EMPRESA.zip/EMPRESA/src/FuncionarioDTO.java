public class FuncionarioDTO {
    private Long id;
    private String nome;
    private String cargo;
    private Double salario;

    public FuncionarioDTO(Long id, String nome, String cargo, Double salario) {
        this.id = id;
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }

    public Long getId() { return id; }
    public String getNome() { return nome; }
    public String getCargo() { return cargo; }
    public Double getSalario() { return salario; }

    @Override
    public String toString() {
        return "ID: " + id + " | Nome: " + nome + " | Cargo: " + cargo + " | Salario: " + salario;
    }
}