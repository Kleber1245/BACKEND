import java.util.ArrayList;
import java.util.List;

public class FuncionarioRepository {
    private List<Funcionario> bancoDeDados = new ArrayList<>();

    public void salvar(Funcionario funcionario) {
        bancoDeDados.add(funcionario);
    }

    public List<Funcionario> buscarTodos() {
        return bancoDeDados;
    }
}