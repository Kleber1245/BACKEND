import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        FuncionarioController controller = new FuncionarioController();
        Scanner scanner = new Scanner(System.in);
        int opcao = 0;

        while (opcao != 3) {
            System.out.println("\n--- SISTEMA DE GESTAO ---");
            System.out.println("1. Cadastrar Funcionario");
            System.out.println("2. Listar Todos");
            System.out.println("3. Sair");
            System.out.print("Escolha uma opcao: ");

            opcao = scanner.nextInt();
            scanner.nextLine();

            if (opcao == 1) {
                System.out.print("Digite o ID: ");
                Long id = scanner.nextLong();
                scanner.nextLine();

                System.out.print("Digite o Nome: ");
                String nome = scanner.nextLine();

                System.out.print("Digite o Cargo: ");
                String cargo = scanner.nextLine();

                System.out.print("Digite o Salario: ");
                Double salario = scanner.nextDouble();

                controller.adicionar(id, nome, cargo, salario);
            } else if (opcao == 2) {
                System.out.println("\n--- Lista de Funcionarios ---");
                controller.exibirTodos();
            }
        }
        System.out.println("Sistema encerrado.");
        scanner.close();
    }
}